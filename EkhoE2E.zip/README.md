# Ekho
This is an extension of the GitHub/scientist concept, specifically designed and packaged up for use in replacing legacy modules with microservices.